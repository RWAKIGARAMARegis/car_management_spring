package com.eddy.Car_Rental_Management_System.model;

public enum Available {
    Booked,
    Available;
}
