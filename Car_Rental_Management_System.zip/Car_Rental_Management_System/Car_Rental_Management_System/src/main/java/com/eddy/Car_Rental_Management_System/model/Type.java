package com.eddy.Car_Rental_Management_System.model;

public enum Type {
    Admin,
    Customer;
}
