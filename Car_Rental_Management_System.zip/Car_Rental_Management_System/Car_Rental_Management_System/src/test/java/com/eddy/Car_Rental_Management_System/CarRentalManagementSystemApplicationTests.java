package com.eddy.Car_Rental_Management_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
